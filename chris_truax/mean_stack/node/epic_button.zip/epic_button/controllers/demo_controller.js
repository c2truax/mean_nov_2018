
module.exports = {

  home_function: function(req, res){

    res.render('index');
  },
  

}
