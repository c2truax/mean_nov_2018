class Cards{
	contructor(value, suit){
		var.stringArr['Ace', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Jack', 'Queen', 'King'];
		var.suitArr = ['Heart', 'Club', 'Diamond', 'Spade'];
		this.value = value;
		this.stringVal = stringArr[value-1];
		this.suit = suitArr[suit-1];
	}
	show(){
		console.log(this.stringVal,this.suit);
	}
}
class Deck{
	contructor(){
		let deckArr = [];
		for(let i = 1; i <=4; i++){
			for(let j = 1; j <= 13; j++){
				deckArr.push(new Card(j,i));
			}
		}
		console.log(deckArr);
		this.deck = deckArr;
	}
	shuffle(){
		let t,i;
		for (let m = 51; m > 0; m--){
			i = Math.floor(Math.random() *m);
			t = this.deck[m];
			this.deck[m] = this.deck[i];
			this.deck[i] = t;
		}
		console.log(this.deck)
	}
	reset(){
		let deckArr = [];
		for(let i = 1; i <=4; i++){
			for(let j = 1; j <= 13; j++){
				deckArr.push(new Card(j,i));
			}
		}
		this.deck = deckArr
	}
	deal(){
		return this.deck.pop();
	}
}
class Player{
	constructor(name){
		this.hand = [];
		for(let i = 0; i < 6; i++){
			this.hand.push(deck.deal());
		}
		console.log(this.hand);
	}
	draw(){
		this.hand.push(deck.deal());
		console.log(this.hand);

	}
	discard(){
		this.hand.pop();
	}
}
playDeck = new Deck;
playDeck .shuffle();
let get = playDeck.deal();
console.log(get)